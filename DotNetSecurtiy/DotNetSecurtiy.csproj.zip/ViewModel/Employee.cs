﻿namespace DotNetSecurtiy.ViewModel
{
    public class Employee
    {

        public Guid Id { get; set; }

        public string EmpName { get; set; }

        public string Department { get; set; }

        public long Salary { get; set; }

    }
}
